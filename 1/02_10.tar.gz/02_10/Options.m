
%% Define Solver
use_ICCG   = true;
use_DICCG  = false;
training   = false;
use_agmg   = false;
use_POD    = false;
plot_sol   = true;
save_res   = true;
use_wells  = false;
model_SPE  = false;
use_cp     = false;
window     = true;
last       = false;  % Last experiment, to close the table


